/**
 * Industrial Salted SHA-256 Password Hashing & Credential Sanitization Utility
 * Zero plaintext passwords stored in client state, seed catalogs, or localStorage.
 * Works deterministically and synchronously in both Browser (PWA/Capacitor) & Node (tsx tests).
 */

import type { UserAccount } from '../types/dental';

const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);

function rotr(x: number, n: number): number {
  return (x >>> n) | (x << (32 - n));
}

export function sha256HexSync(input: string): string {
  const bytes = new TextEncoder().encode(input);
  const bitLen = bytes.length * 8;
  const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(bytes);
  buf[bytes.length] = 0x80;

  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(paddedLen - 4, bitLen >>> 0, false);

  const H = new Uint32Array([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
  ]);

  const W = new Uint32Array(64);
  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      W[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(W[i - 15], 7) ^ rotr(W[i - 15], 18) ^ (W[i - 15] >>> 3);
      const s1 = rotr(W[i - 2], 17) ^ rotr(W[i - 2], 19) ^ (W[i - 2] >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) >>> 0;
    }

    let a = H[0], b = H[1], c = H[2], d = H[3];
    let e = H[4], f = H[5], g = H[6], h = H[7];

    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[i] + W[i]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    H[0] = (H[0] + a) >>> 0;
    H[1] = (H[1] + b) >>> 0;
    H[2] = (H[2] + c) >>> 0;
    H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0;
    H[5] = (H[5] + f) >>> 0;
    H[6] = (H[6] + g) >>> 0;
    H[7] = (H[7] + h) >>> 0;
  }

  return Array.from(H)
    .map(w => w.toString(16).padStart(8, '0'))
    .join('');
}

function generateSalt(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    const arr = new Uint8Array(8);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(16).slice(2, 10) + Date.now().toString(16).slice(-6);
}

/**
 * Generates a salted SHA-256 password hash string: sha256$<salt>$<digest>
 */
export function hashPasswordSync(plain: string, customSalt?: string): string {
  const salt = customSalt || generateSalt();
  // Key-stretched multi-round hash for stronger client verification
  let digest = sha256HexSync(`${salt}:${plain}:minadental-v27`);
  for (let i = 0; i < 64; i++) {
    digest = sha256HexSync(`${digest}:${salt}:${i}`);
  }
  return `sha256$${salt}$${digest}`;
}

/**
 * Constant-time string comparison to avoid timing leaks
 */
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

/**
 * Verifies user password against salted passwordHash (with backward compatibility for legacy unmigrated records)
 */
export function verifyPasswordCredential(
  plainInput: string,
  account: Pick<UserAccount, 'passwordHash' | 'password'>
): boolean {
  const cleanInput = plainInput.trim();
  if (!cleanInput) return false;

  if (account.passwordHash && account.passwordHash.startsWith('sha256$')) {
    const parts = account.passwordHash.split('$');
    if (parts.length === 3) {
      const salt = parts[1];
      const expected = hashPasswordSync(cleanInput, salt);
      return safeEqual(expected, account.passwordHash);
    }
  }

  if (account.password) {
    return safeEqual(cleanInput, account.password.trim());
  }

  return false;
}

/**
 * Strips raw plaintext passwords and ensures salted passwordHash exists before saving to state/storage
 */
export function sanitizeUserAccount(user: UserAccount, rawPasswordOverride?: string): UserAccount {
  const next = { ...user };
  const candidatePlain = rawPasswordOverride?.trim() || next.password?.trim();
  if (candidatePlain) {
    next.passwordHash = hashPasswordSync(candidatePlain);
  }
  delete next.password;
  return next;
}

export function sanitizeUsersList(users: UserAccount[]): UserAccount[] {
  return users.map(u => sanitizeUserAccount(u));
}
